"""PySide6 interface: animated orb, live system HUD, conversation view, settings."""
import math
import random

import psutil
import sounddevice as sd
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QFrame,
                               QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QPushButton,
                               QScrollArea, QSizePolicy, QSlider, QVBoxLayout, QWidget)

from config import LANGUAGES

INK, PANEL, LINE, TEXT, MUTED = "#060A12", "#0C1424", "#1C2B47", "#E6EEF9", "#7C8DA8"
STATE_COLORS = {"loading": "#7C8DA8", "idle": "#38E1F2", "listening": "#4DFFB0", "thinking": "#A58BFF",
                "speaking": "#5AA8FF", "alert": "#FF5C6C", "muted": "#4A5870"}
STATE_LABELS = {"loading": "Starting up", "idle": "Standing by", "listening": "Listening",
                "thinking": "Thinking", "speaking": "Speaking", "alert": "Needs attention", "muted": "Mic off"}

QSS = f"""
* {{ font-family: "Segoe UI Variable", "Segoe UI", "Nirmala UI", "Noto Sans Telugu", "Noto Sans Devanagari", "Noto Sans Tamil", sans-serif; color: {TEXT}; }}
QMainWindow, QDialog {{ background: {INK}; }}
QFrame#panel {{ background: {PANEL}; border: 1px solid {LINE}; border-radius: 14px; }}
QLabel#muted {{ color: {MUTED}; }}
QPushButton {{ background: {PANEL}; border: 1px solid {LINE}; border-radius: 10px; padding: 9px 14px; }}
QPushButton:hover {{ border-color: #38E1F2; }}
QPushButton:focus {{ border-color: #38E1F2; }}
QPushButton#primary {{ background: #38E1F2; color: #04222A; border: none; font-weight: 600; }}
QPushButton#primary:hover {{ background: #6AEBF7; }}
QLineEdit, QComboBox {{ background: {INK}; border: 1px solid {LINE}; border-radius: 10px; padding: 9px 12px; }}
QLineEdit:focus {{ border-color: #38E1F2; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 8px; }}
QScrollBar::handle:vertical {{ background: {LINE}; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
"""


class Orb(QWidget):
    clicked = Signal()

    def __init__(self):
        super().__init__()
        self.state, self.level, self.smooth, self.t = "loading", 0.0, 0.0, 0.0
        self.color = QColor(STATE_COLORS["loading"])
        self.setMinimumSize(300, 300)
        self.setCursor(Qt.PointingHandCursor)
        self.timer = QTimer(self, timeout=self.tick, interval=16)
        self.timer.start()
        self.phases = [random.random() * 6.28 for _ in range(72)]

    def set_state(self, s):
        self.state = s

    def set_level(self, v):
        self.level = max(0.0, v)

    def mousePressEvent(self, e):
        self.clicked.emit()

    def tick(self):
        self.t += 0.016
        target = self.level
        if self.state == "speaking":
            target = 0.35 + 0.3 * abs(math.sin(self.t * 7.3) * math.sin(self.t * 2.9))
        elif self.state == "thinking":
            target = 0.18 + 0.1 * math.sin(self.t * 4)
        elif self.state in ("idle", "loading", "muted"):
            target = 0.04 * self.level
        self.smooth += (target - self.smooth) * 0.22
        goal = QColor(STATE_COLORS.get(self.state, "#38E1F2"))
        self.color = QColor(*(int(a + (b - a) * 0.12) for a, b in zip(self.color.getRgb()[:3], goal.getRgb()[:3])))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        c = QPointF(w / 2, h / 2)
        R = min(w, h) * 0.26
        col = self.color
        speed = {"thinking": 2.6, "alert": 3.2, "speaking": 1.6}.get(self.state, 0.8)
        breathe = 1 + (0.035 + self.smooth * 0.28) * math.sin(self.t * speed * 2.2)
        r = R * breathe

        glow = QRadialGradient(c, r * 2.6)
        g0, g1 = QColor(col), QColor(col)
        g0.setAlpha(70 + int(self.smooth * 120))
        g1.setAlpha(0)
        glow.setColorAt(0, g0)
        glow.setColorAt(1, g1)
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(glow))
        p.drawEllipse(c, r * 2.6, r * 2.6)

        core = QRadialGradient(QPointF(c.x() - r * 0.3, c.y() - r * 0.35), r * 1.2)
        hi, mid, lo = QColor(col).lighter(170), QColor(col), QColor(col).darker(320)
        core.setColorAt(0, hi)
        core.setColorAt(0.45, mid)
        core.setColorAt(1, lo)
        p.setBrush(QBrush(core))
        p.drawEllipse(c, r, r)

        for i, (scale, width, span, dirn) in enumerate([(1.28, 2.0, 110, 1), (1.45, 1.4, 70, -1), (1.62, 1.0, 40, 1)]):
            ring = QColor(col)
            ring.setAlpha(190 - i * 45)
            p.setPen(QPen(ring, width, Qt.SolidLine, Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            rr = r * scale
            rect = QRectF(c.x() - rr, c.y() - rr, rr * 2, rr * 2)
            base = self.t * (24 + i * 16) * dirn * speed
            for k in range(3):
                p.drawArc(rect, int((base + k * 120) * 16), int(span * 16))

        n = len(self.phases)
        amp = self.smooth * 70
        for i in range(n):
            a = i / n * 6.2832
            wave = 0.5 + 0.5 * math.sin(self.t * 5 + self.phases[i]) * math.sin(a * 3 + self.t * 2)
            ln = 3 + amp * wave
            r0, r1 = r * 1.82, r * 1.82 + ln
            bar = QColor(col)
            bar.setAlpha(80 + int(150 * min(1, ln / 40)))
            p.setPen(QPen(bar, 2.2, Qt.SolidLine, Qt.RoundCap))
            p.drawLine(QPointF(c.x() + math.cos(a) * r0, c.y() + math.sin(a) * r0),
                       QPointF(c.x() + math.cos(a) * r1, c.y() + math.sin(a) * r1))


class Gauge(QWidget):
    def __init__(self, label):
        super().__init__()
        self.label, self.value, self.note = label, 0, ""
        self.setMinimumSize(110, 104)

    def set(self, v, note=""):
        self.value, self.note = v, note
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        side = min(w, h - 22) - 14
        rect = QRectF((w - side) / 2, 6, side, side)
        p.setPen(QPen(QColor(LINE), 7, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(rect, 225 * 16, -270 * 16)
        hot = self.value >= 90 if self.label != "Battery" else self.value <= 15
        col = QColor("#FF5C6C" if hot else "#38E1F2")
        p.setPen(QPen(col, 7, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(rect, 225 * 16, int(-270 * 16 * min(100, self.value) / 100))
        p.setPen(QColor(TEXT))
        f = QFont(self.font())
        f.setPointSize(13)
        f.setBold(True)
        p.setFont(f)
        p.drawText(rect, Qt.AlignCenter, f"{self.value:.0f}")
        f.setPointSize(9)
        f.setBold(False)
        p.setFont(f)
        p.setPen(QColor(MUTED))
        p.drawText(QRectF(0, h - 20, w, 18), Qt.AlignCenter, self.label + (f"  {self.note}" if self.note else ""))


class Bubble(QFrame):
    def __init__(self, role, text, lang):
        super().__init__()
        me = role == "you"
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)
        if lang != "en" and lang in LANGUAGES:
            tag = QLabel(LANGUAGES[lang]["native"])
            tag.setObjectName("muted")
            lay.addWidget(tag)
        lbl = QLabel(text)
        lbl.setWordWrap(True)
        lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lbl.setStyleSheet("font-size: 14px;")
        lay.addWidget(lbl)
        bg, bd = ("#12304A", "#1F5A82") if me else (PANEL, LINE)
        self.setStyleSheet(f"Bubble {{ background: {bg}; border: 1px solid {bd}; border-radius: 14px; }}")
        self.setMaximumWidth(520)


class Chat(QScrollArea):
    def __init__(self):
        super().__init__()
        self.setWidgetResizable(True)
        inner = QWidget()
        self.col = QVBoxLayout(inner)
        self.col.setContentsMargins(4, 4, 8, 4)
        self.col.setSpacing(8)
        self.col.addStretch()
        self.setWidget(inner)

    def add(self, role, text, lang="en"):
        row = QHBoxLayout()
        b = Bubble(role, text, lang)
        if role == "you":
            row.addStretch()
            row.addWidget(b)
        else:
            row.addWidget(b)
            row.addStretch()
        self.col.insertLayout(self.col.count() - 1, row)
        QTimer.singleShot(30, lambda: self.verticalScrollBar().setValue(self.verticalScrollBar().maximum()))


def panel():
    f = QFrame()
    f.setObjectName("panel")
    return f


class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.s = settings
        self.setWindowTitle("Settings")
        self.setMinimumWidth(460)
        form = QFormLayout(self)
        form.setSpacing(12)
        self.name = QLineEdit(settings.get("assistant_name"))
        self.title = QLineEdit(settings.get("master_title"))
        self.key = QLineEdit(settings.get("api_key"))
        self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText("sk-ant-…  (or set ANTHROPIC_API_KEY)")
        self.model = QLineEdit(settings.get("model"))
        self.whisper = QComboBox()
        self.whisper.addItems(["small", "medium", "large-v3"])
        self.whisper.setCurrentText(settings.get("whisper_model"))
        self.wake = QCheckBox("Wait for my assistant's name before listening")
        self.wake.setChecked(settings.get("require_wake_word"))
        self.speak = QCheckBox("Speak replies aloud")
        self.speak.setChecked(settings.get("speak_replies"))
        self.thr = QSlider(Qt.Horizontal)
        self.thr.setRange(50, 90)
        self.thr.setValue(int(settings.get("speaker_threshold") * 100))
        self.thr_lbl = QLabel(f"{self.thr.value() / 100:.2f}")
        self.thr.valueChanged.connect(lambda v: self.thr_lbl.setText(f"{v / 100:.2f}"))
        trow = QHBoxLayout()
        trow.addWidget(self.thr)
        trow.addWidget(self.thr_lbl)
        self.langs = {}
        lrow = QHBoxLayout()
        for code, meta in LANGUAGES.items():
            cb = QCheckBox(f"{meta['name']} {meta['native']}" if code != "en" else "English")
            cb.setChecked(code in settings.get("languages"))
            self.langs[code] = cb
            lrow.addWidget(cb)
        self.mic = QComboBox()
        self.mic.addItem("System default", None)
        for i, d in enumerate(sd.query_devices()):
            if d["max_input_channels"] > 0:
                self.mic.addItem(d["name"], i)
        idx = self.mic.findData(settings.get("input_device"))
        self.mic.setCurrentIndex(max(0, idx))
        form.addRow("Assistant name", self.name)
        form.addRow("Call me", self.title)
        form.addRow("Anthropic API key", self.key)
        form.addRow("Model", self.model)
        form.addRow("Languages", lrow)
        form.addRow("Speech accuracy", self.whisper)
        form.addRow("Voice match strictness", trow)
        form.addRow("Microphone", self.mic)
        form.addRow("", self.wake)
        form.addRow("", self.speak)
        note = QLabel("Speech accuracy, microphone and language changes apply after restart.")
        note.setObjectName("muted")
        form.addRow("", note)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.save)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def save(self):
        langs = [c for c, cb in self.langs.items() if cb.isChecked()] or ["en"]
        self.s.set(assistant_name=self.name.text().strip() or "Jarvis",
                   master_title=self.title.text().strip() or "Master",
                   api_key=self.key.text().strip(), model=self.model.text().strip() or "claude-sonnet-5-5",
                   languages=langs, whisper_model=self.whisper.currentText(),
                   speaker_threshold=self.thr.value() / 100, require_wake_word=self.wake.isChecked(),
                   speak_replies=self.speak.isChecked(), input_device=self.mic.currentData())
        self.accept()


class MainWindow(QMainWindow):
    def __init__(self, engine, bus):
        super().__init__()
        self.e, self.bus, self.s = engine, bus, engine.s
        self.setWindowTitle("Voice Assistant")
        self.resize(1180, 760)
        self.setMinimumSize(980, 640)
        self.setStyleSheet(QSS)
        self.alert_ticks, self.bat_warned = 0, 0

        root = QWidget()
        self.setCentralWidget(root)
        h = QHBoxLayout(root)
        h.setContentsMargins(18, 18, 18, 18)
        h.setSpacing(16)

        # ----- sidebar -----
        side = QVBoxLayout()
        side.setSpacing(12)
        head = QVBoxLayout()
        self.title = QLabel(self.s.get("assistant_name"))
        self.title.setStyleSheet("font-size: 28px; font-weight: 600;")
        self.sub = QLabel()
        self.sub.setObjectName("muted")
        head.addWidget(self.title)
        head.addWidget(self.sub)
        side.addLayout(head)

        gp = panel()
        grid = QGridLayout(gp)
        grid.setContentsMargins(10, 10, 10, 6)
        self.g_cpu, self.g_ram, self.g_bat, self.g_disk = Gauge("CPU"), Gauge("Memory"), Gauge("Battery"), Gauge("Disk")
        for i, g in enumerate((self.g_cpu, self.g_ram, self.g_bat, self.g_disk)):
            grid.addWidget(g, i // 2, i % 2)
        side.addWidget(gp)

        lp = panel()
        lv = QVBoxLayout(lp)
        lv.setContentsMargins(14, 12, 14, 12)
        cap = QLabel("I understand")
        cap.setObjectName("muted")
        lv.addWidget(cap)
        chips = QHBoxLayout()
        self.chips = {}
        for code, meta in LANGUAGES.items():
            c = QLabel(meta["native"])
            c.setAlignment(Qt.AlignCenter)
            self.chips[code] = c
            chips.addWidget(c)
        lv.addLayout(chips)
        side.addWidget(lp)

        vp = panel()
        vv = QVBoxLayout(vp)
        vv.setContentsMargins(14, 12, 14, 12)
        self.voice_lbl = QLabel("Voice lock: not set up")
        self.voice_lbl.setStyleSheet("font-weight: 600;")
        self.voice_sub = QLabel("Only your voice will be obeyed once enrolled.")
        self.voice_sub.setObjectName("muted")
        self.voice_sub.setWordWrap(True)
        self.enroll_btn = QPushButton("Enroll my voice")
        self.enroll_btn.setObjectName("primary")
        self.enroll_btn.clicked.connect(self.e.enroll)
        vv.addWidget(self.voice_lbl)
        vv.addWidget(self.voice_sub)
        vv.addWidget(self.enroll_btn)
        side.addWidget(vp)

        row = QHBoxLayout()
        self.mic_btn = QPushButton("Mute mic")
        self.mic_btn.clicked.connect(self.toggle_mic)
        st = QPushButton("Settings")
        st.clicked.connect(self.open_settings)
        row.addWidget(self.mic_btn)
        row.addWidget(st)
        side.addLayout(row)
        side.addStretch()
        sw = QWidget()
        sw.setLayout(side)
        sw.setFixedWidth(300)
        h.addWidget(sw)

        # ----- main -----
        main = QVBoxLayout()
        main.setSpacing(10)
        self.orb = Orb()
        self.orb.clicked.connect(self.orb_clicked)
        main.addWidget(self.orb, 5)
        self.state_lbl = QLabel("Starting up")
        self.state_lbl.setAlignment(Qt.AlignCenter)
        self.state_lbl.setStyleSheet("font-size: 20px; font-weight: 600;")
        self.status = QLabel("")
        self.status.setObjectName("muted")
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setWordWrap(True)
        main.addWidget(self.state_lbl)
        main.addWidget(self.status)
        self.chat = Chat()
        self.chat.setMinimumHeight(170)
        main.addWidget(self.chat, 4)
        inp = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setPlaceholderText("Type a command, or just speak")
        self.input.returnPressed.connect(self.send)
        send = QPushButton("Send")
        send.setObjectName("primary")
        send.clicked.connect(self.send)
        inp.addWidget(self.input)
        inp.addWidget(send)
        main.addLayout(inp)
        h.addLayout(main, 1)

        # ----- wiring -----
        b = self.bus
        b.state.connect(self.on_state)
        b.level.connect(self.orb.set_level)
        b.status.connect(self.status.setText)
        b.transcript.connect(self.chat.add)
        b.verified.connect(self.on_verified)
        b.lang.connect(self.on_lang)
        b.settings_changed.connect(self.refresh_identity)
        b.enrolled.connect(self.on_enrolled)
        self.refresh_identity()
        self.on_state("loading")
        self.mon = QTimer(self, timeout=self.monitor, interval=2000)
        self.mon.start()
        self.monitor()

    # ----- slots -----
    def refresh_identity(self):
        self.title.setText(self.s.get("assistant_name"))
        self.sub.setText(f"At your service, {self.s.get('master_title')}.")
        for code, c in self.chips.items():
            on = code in self.s.get("languages")
            c.setStyleSheet(f"padding: 6px 4px; border-radius: 9px; border: 1px solid {LINE}; "
                            f"color: {TEXT if on else '#3B4A63'}; background: {INK};")

    def on_state(self, s):
        self.orb.set_state(s)
        self.state_lbl.setText(STATE_LABELS.get(s, s))

    def on_lang(self, code):
        for k, c in self.chips.items():
            on = k in self.s.get("languages")
            hit = k == code
            c.setStyleSheet(f"padding: 6px 4px; border-radius: 9px; "
                            f"border: 1px solid {'#38E1F2' if hit else LINE}; "
                            f"color: {TEXT if on else '#3B4A63'}; background: {'#0F2A33' if hit else INK};")
        QTimer.singleShot(2500, self.refresh_identity)

    def on_enrolled(self, ok):
        self.voice_lbl.setText("Voice lock: on" if ok else "Voice lock: not set up")
        self.voice_sub.setText("Only your voice is obeyed." if ok else "Enroll once so only you can command me.")
        self.enroll_btn.setText("Re-enroll my voice" if ok else "Enroll my voice")
        self.enroll_btn.setObjectName("" if ok else "primary")
        self.enroll_btn.setStyleSheet(self.enroll_btn.styleSheet())
        self.style().unpolish(self.enroll_btn)
        self.style().polish(self.enroll_btn)

    def on_verified(self, ok, score):
        if ok:
            self.voice_sub.setText(f"Your voice matched ({score:.2f}).")
        else:
            self.voice_sub.setText(f"Unrecognised voice ignored ({score:.2f}).")
            self.voice_lbl.setStyleSheet("font-weight: 600; color: #FF5C6C;")
            QTimer.singleShot(2500, lambda: self.voice_lbl.setStyleSheet("font-weight: 600;"))

    def orb_clicked(self):
        if self.orb.state == "speaking":
            self.e.stop_speaking()
        else:
            self.e.listen_now()

    def toggle_mic(self):
        muted = self.e.toggle_mute()
        self.mic_btn.setText("Unmute mic" if muted else "Mute mic")

    def send(self):
        t = self.input.text().strip()
        if t:
            self.input.clear()
            self.e.submit_text(t)

    def open_settings(self):
        if SettingsDialog(self.s, self).exec():
            self.refresh_identity()
            self.status.setText("Settings saved.")

    def monitor(self):
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage("/").percent
        bat = psutil.sensors_battery()
        self.g_cpu.set(cpu)
        self.g_ram.set(ram)
        self.g_disk.set(disk)
        if bat:
            self.g_bat.set(bat.percent, "charging" if bat.power_plugged else "")
        else:
            self.g_bat.set(100, "plugged in")
        t = self.s.get("master_title")
        self.alert_ticks = self.alert_ticks + 1 if (cpu > 92 or ram > 94) else 0
        if self.alert_ticks == 4 and self.e.ready:
            self.alert_ticks = -30
            self.bus.state.emit("alert")
            self.e.proactive(f"{t}, the system is under heavy load. CPU is at {cpu:.0f} percent and memory at {ram:.0f} percent. "
                             "Shall I find what is causing it?")
        if bat and not bat.power_plugged and bat.percent <= 15 and self.bat_warned <= 0 and self.e.ready:
            self.bat_warned = 150
            self.bus.state.emit("alert")
            self.e.proactive(f"{t}, battery is at {bat.percent:.0f} percent. Shall I switch to power saver and dim the screen?")
        self.bat_warned -= 1
