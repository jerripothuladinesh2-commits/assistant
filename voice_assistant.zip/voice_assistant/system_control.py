"""Laptop control tools the assistant can call. Windows first, with macOS/Linux fallbacks."""
import datetime
import os
import platform
import shutil
import subprocess
import threading
import time
import webbrowser
from pathlib import Path

import psutil

from config import NOTES_FILE

OS = platform.system()          # Windows | Darwin | Linux
PROTECTED = {"system", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe",
             "services.exe", "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe",
             "python.exe", "pythonw.exe", "python", "python3", "systemd", "init", "kernel_task"}

APP_ALIASES = {
    "spotify": {"Windows": "spotify:", "Darwin": "Spotify", "Linux": "spotify"},
    "chrome": {"Windows": "chrome", "Darwin": "Google Chrome", "Linux": "google-chrome"},
    "browser": {"Windows": "msedge", "Darwin": "Safari", "Linux": "xdg-open https://google.com"},
    "edge": {"Windows": "msedge"},
    "firefox": {"Windows": "firefox", "Darwin": "Firefox", "Linux": "firefox"},
    "notepad": {"Windows": "notepad", "Darwin": "TextEdit", "Linux": "gedit"},
    "calculator": {"Windows": "calc", "Darwin": "Calculator", "Linux": "gnome-calculator"},
    "word": {"Windows": "winword"}, "excel": {"Windows": "excel"}, "powerpoint": {"Windows": "powerpnt"},
    "vscode": {"Windows": "code", "Darwin": "Visual Studio Code", "Linux": "code"},
    "terminal": {"Windows": "wt", "Darwin": "Terminal", "Linux": "gnome-terminal"},
    "explorer": {"Windows": "explorer", "Darwin": "Finder", "Linux": "xdg-open ."},
    "settings": {"Windows": "ms-settings:", "Darwin": "System Settings"},
    "whatsapp": {"Windows": "whatsapp:", "Darwin": "WhatsApp"},
    "camera": {"Windows": "microsoft.windows.camera:"},
}


def _run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=15, **kw)


def _tool(name, desc, props=None, required=None):
    return {"name": name, "description": desc,
            "input_schema": {"type": "object", "properties": props or {}, "required": required or []}}


class SystemControl:
    def __init__(self, settings, memory, notify, on_settings):
        self.s, self.mem, self.notify, self.on_settings = settings, memory, notify, on_settings

    # ---------- schema ----------
    def tools(self):
        i, s, b = {"type": "integer"}, {"type": "string"}, {"type": "boolean"}
        return [
            _tool("get_system_status", "Battery, CPU, RAM, disk, temperature and the heaviest processes."),
            _tool("set_volume", "Set speaker volume 0-100.", {"level": i}, ["level"]),
            _tool("change_volume", "Raise or lower volume by a delta in percent (e.g. 10 or -10).", {"delta": i}, ["delta"]),
            _tool("mute", "Mute or unmute speakers.", {"muted": b}, ["muted"]),
            _tool("set_brightness", "Set screen brightness 0-100.", {"level": i}, ["level"]),
            _tool("change_brightness", "Raise or lower brightness by a delta in percent.", {"delta": i}, ["delta"]),
            _tool("set_wifi", "Turn Wi-Fi on or off.", {"on": b}, ["on"]),
            _tool("set_bluetooth", "Turn Bluetooth on or off (opens settings on Windows).", {"on": b}, ["on"]),
            _tool("set_power_mode", "Switch power mode.", {"mode": {"type": "string", "enum": ["saver", "balanced", "performance"]}}, ["mode"]),
            _tool("open_app", "Open an application by name (spotify, chrome, notepad, vscode...).", {"name": s}, ["name"]),
            _tool("close_app", "Gracefully close all processes whose name contains the text. Ask Master first.", {"name": s}, ["name"]),
            _tool("kill_process", "Force-terminate a process by name or PID. Only after Master confirms.", {"target": s}, ["target"]),
            _tool("find_files", "Search Desktop/Documents/Downloads/Pictures for file names containing a query.", {"query": s}, ["query"]),
            _tool("open_file", "Open a file or folder path with its default app.", {"path": s}, ["path"]),
            _tool("open_url", "Open a website in the browser.", {"url": s}, ["url"]),
            _tool("web_search", "Search the web in the browser.", {"query": s}, ["query"]),
            _tool("take_screenshot", "Save a screenshot to the Pictures folder."),
            _tool("media_control", "Control media playback.", {"action": {"type": "string", "enum": ["playpause", "next", "previous"]}}, ["action"]),
            _tool("set_timer", "Set a timer or reminder that will be spoken when done.", {"seconds": i, "label": s}, ["seconds"]),
            _tool("lock_screen", "Lock the laptop."),
            _tool("save_voice_note", "Save a note dictated by Master.", {"text": s}, ["text"]),
            _tool("read_voice_notes", "Read back the latest saved voice notes."),
            _tool("set_assistant_name", "Change the assistant's own name.", {"name": s}, ["name"]),
            _tool("set_master_title", "Change what the assistant calls the user (Master, Boss, Sir, a name...).", {"title": s}, ["title"]),
            _tool("remember_preference", "Store a routine, default app, volume level or habit for later.", {"key": s, "value": s}, ["key", "value"]),
        ]

    def run(self, name, args):
        fn = getattr(self, "t_" + name, None)
        if not fn:
            return f"Unknown tool {name}"
        try:
            return str(fn(**args))
        except Exception as e:
            return f"{name} failed: {e}"

    # ---------- diagnostics ----------
    def t_get_system_status(self):
        bat = psutil.sensors_battery()
        out = [f"CPU {psutil.cpu_percent(interval=0.4):.0f}%",
               f"RAM {psutil.virtual_memory().percent:.0f}% used",
               f"Disk {psutil.disk_usage(str(Path.home().anchor or '/')).percent:.0f}% used"]
        if bat:
            out.append(f"Battery {bat.percent:.0f}% ({'charging' if bat.power_plugged else 'on battery'})")
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                out.append(f"Temp {max(t.current for v in temps.values() for t in v):.0f}C")
        except Exception:
            pass
        out.append("Heaviest: " + self.t_list_heavy_processes(4))
        return "; ".join(out)

    def t_list_heavy_processes(self, n=5):
        procs = []
        for p in psutil.process_iter(["name", "memory_percent", "cpu_percent"]):
            try:
                procs.append((p.info["memory_percent"] or 0, p.info["cpu_percent"] or 0, p.info["name"]))
            except Exception:
                pass
        agg = {}
        for mem, cpu, nm in procs:
            a = agg.setdefault(nm, [0, 0])
            a[0] += mem
            a[1] += cpu
        top = sorted(agg.items(), key=lambda kv: kv[1][0], reverse=True)[:n]
        return ", ".join(f"{k} {v[0]:.0f}% RAM" for k, v in top)

    # ---------- volume / brightness ----------
    def _win_volume(self):
        import comtypes
        from ctypes import POINTER, cast
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        try:
            comtypes.CoInitialize()
        except Exception:
            pass
        dev = AudioUtilities.GetSpeakers()
        if hasattr(dev, "EndpointVolume"):
            return dev.EndpointVolume
        iface = dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return cast(iface, POINTER(IAudioEndpointVolume))

    def _get_volume(self):
        if OS == "Windows":
            return round(self._win_volume().GetMasterVolumeLevelScalar() * 100)
        if OS == "Darwin":
            return int(_run(["osascript", "-e", "output volume of (get volume settings)"]).stdout.strip())
        out = _run(["amixer", "get", "Master"]).stdout
        return int(out.split("[")[1].split("%")[0])

    def t_set_volume(self, level):
        level = max(0, min(100, int(level)))
        if OS == "Windows":
            self._win_volume().SetMasterVolumeLevelScalar(level / 100, None)
        elif OS == "Darwin":
            _run(["osascript", "-e", f"set volume output volume {level}"])
        else:
            _run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"])
        return f"Volume set to {level}%"

    def t_change_volume(self, delta):
        return self.t_set_volume(self._get_volume() + int(delta))

    def t_mute(self, muted):
        if OS == "Windows":
            self._win_volume().SetMute(1 if muted else 0, None)
        elif OS == "Darwin":
            _run(["osascript", "-e", f"set volume output muted {'true' if muted else 'false'}"])
        else:
            _run(["amixer", "-D", "pulse", "sset", "Master", "mute" if muted else "unmute"])
        return "Muted" if muted else "Unmuted"

    def t_set_brightness(self, level):
        import screen_brightness_control as sbc
        level = max(0, min(100, int(level)))
        sbc.set_brightness(level)
        return f"Brightness set to {level}%"

    def t_change_brightness(self, delta):
        import screen_brightness_control as sbc
        cur = sbc.get_brightness()[0]
        return self.t_set_brightness(cur + int(delta))

    # ---------- radios / power ----------
    def t_set_wifi(self, on):
        state = "on" if on else "off"
        if OS == "Windows":
            r = _run(["netsh", "interface", "set", "interface", "name=Wi-Fi",
                      f"admin={'enabled' if on else 'disabled'}"])
            if r.returncode:
                return "Windows needs the assistant to run as administrator to toggle Wi-Fi."
        elif OS == "Darwin":
            _run(["networksetup", "-setairportpower", "en0", state])
        else:
            _run(["nmcli", "radio", "wifi", state])
        return f"Wi-Fi {state}"

    def t_set_bluetooth(self, on):
        if OS == "Linux":
            _run(["rfkill", "unblock" if on else "block", "bluetooth"])
            return f"Bluetooth {'on' if on else 'off'}"
        if OS == "Windows":
            os.startfile("ms-settings:bluetooth")
            return "Opened Bluetooth settings; Windows does not allow a silent toggle."
        return "Bluetooth toggle is not supported on this system."

    def t_set_power_mode(self, mode):
        if OS == "Windows":
            guid = {"saver": "SCHEME_MAX", "balanced": "SCHEME_BALANCED", "performance": "SCHEME_MIN"}[mode]
            _run(["powercfg", "/setactive", guid])
        elif OS == "Linux":
            _run(["powerprofilesctl", "set", {"saver": "power-saver", "balanced": "balanced", "performance": "performance"}[mode]])
        else:
            return "Power modes are not scriptable on this system."
        return f"Power mode {mode}"

    # ---------- apps / processes ----------
    def t_open_app(self, name):
        key = name.lower().strip()
        target = APP_ALIASES.get(key, {}).get(OS, name)
        if OS == "Windows":
            subprocess.Popen(f'start "" "{target}"', shell=True)
        elif OS == "Darwin":
            subprocess.Popen(["open", "-a", target])
        else:
            subprocess.Popen(target.split() if shutil.which(target.split()[0]) else ["xdg-open", target])
        return f"Opening {name}"

    def t_close_app(self, name):
        n, closed = name.lower(), 0
        for p in psutil.process_iter(["name"]):
            nm = (p.info["name"] or "").lower()
            if n in nm and nm not in PROTECTED:
                try:
                    p.terminate()
                    closed += 1
                except Exception:
                    pass
        return f"Closed {closed} process(es) matching {name}" if closed else f"Nothing running matches {name}"

    def t_kill_process(self, target):
        if str(target).isdigit():
            p = psutil.Process(int(target))
            if (p.name() or "").lower() in PROTECTED:
                return "That is a protected system process."
            p.kill()
            return f"Terminated {p.name()}"
        n, killed = str(target).lower(), 0
        for p in psutil.process_iter(["name"]):
            nm = (p.info["name"] or "").lower()
            if n in nm and nm not in PROTECTED:
                try:
                    p.kill()
                    killed += 1
                except Exception:
                    pass
        return f"Terminated {killed} process(es)" if killed else "No matching process, or it is protected."

    # ---------- files / web ----------
    def t_find_files(self, query):
        q, hits, deadline = query.lower(), [], time.time() + 6
        for folder in ("Desktop", "Documents", "Downloads", "Pictures"):
            root = Path.home() / folder
            for dp, _, files in os.walk(root):
                for f in files:
                    if q in f.lower():
                        hits.append(os.path.join(dp, f))
                if len(hits) >= 5 or time.time() > deadline:
                    break
            if len(hits) >= 5:
                break
        return "\n".join(hits) if hits else "No matching files found."

    def t_open_file(self, path):
        if OS == "Windows":
            os.startfile(path)
        elif OS == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return f"Opened {Path(path).name}"

    def t_open_url(self, url):
        webbrowser.open(url if "://" in url else "https://" + url)
        return f"Opened {url}"

    def t_web_search(self, query):
        webbrowser.open("https://www.google.com/search?q=" + query.replace(" ", "+"))
        return f"Searching for {query}"

    def t_take_screenshot(self):
        import pyautogui
        folder = Path.home() / "Pictures" / "Screenshots"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"shot_{datetime.datetime.now():%Y%m%d_%H%M%S}.png"
        pyautogui.screenshot(str(path))
        return f"Screenshot saved as {path.name} in Pictures/Screenshots"

    def t_media_control(self, action):
        import pyautogui
        pyautogui.press({"playpause": "playpause", "next": "nexttrack", "previous": "prevtrack"}[action])
        return f"Media: {action}"

    def t_set_timer(self, seconds, label="your timer"):
        seconds = max(1, int(seconds))
        threading.Timer(seconds, lambda: self.notify(f"{self.s.get('master_title')}, {label} is done.")).start()
        return f"Timer set for {seconds} seconds"

    def t_lock_screen(self):
        if OS == "Windows":
            import ctypes
            ctypes.windll.user32.LockWorkStation()
        elif OS == "Darwin":
            _run(["pmset", "displaysleepnow"])
        else:
            _run(["loginctl", "lock-session"])
        return "Screen locked"

    # ---------- notes / identity / memory ----------
    def t_save_voice_note(self, text):
        with open(NOTES_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now():%Y-%m-%d %H:%M}] {text}\n")
        return "Note saved"

    def t_read_voice_notes(self):
        if not NOTES_FILE.exists():
            return "No notes yet."
        return "".join(NOTES_FILE.read_text(encoding="utf-8").splitlines(True)[-5:])

    def t_set_assistant_name(self, name):
        self.s.set(assistant_name=name.strip())
        self.on_settings()
        return f"My name is now {name}"

    def t_set_master_title(self, title):
        self.s.set(master_title=title.strip())
        self.on_settings()
        return f"I will address you as {title}"

    def t_remember_preference(self, key, value):
        self.mem.remember(key, value)
        return "Remembered"
