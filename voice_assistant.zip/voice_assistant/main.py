import sys

from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import QApplication

from engine import Bus, Engine
from gui import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Voice Assistant")
    bus = Bus()
    engine = Engine(bus)
    win = MainWindow(engine, bus)
    QShortcut(QKeySequence("Ctrl+Space"), win, activated=engine.listen_now)
    win.show()
    engine.start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
