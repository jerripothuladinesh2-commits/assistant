# Voice Assistant (Jarvis-style, Master-only)

A desktop voice assistant that obeys only your voice, understands English, Telugu, Hindi and Tamil,
controls your laptop, and has a live animated interface.

## Install (Python 3.10 to 3.12)

```
python -m venv venv
venv\Scripts\activate          (Windows)    source venv/bin/activate   (macOS/Linux)
pip install -r requirements.txt
python main.py
```

## First run

1. Open Settings, paste your Anthropic API key, save.
2. Tap Enroll my voice and read the six sentences shown. This creates your voiceprint.
3. Say "Jarvis, open Spotify and set the volume to fifty percent" or tap the orb (or press Ctrl+Space) and just talk.
   Telugu, Hindi and Tamil work the same way, for example "జార్విస్, బ్యాటరీ ఎంత ఉంది?".

Models (speech recognition, voice matching) download on the first launch. Internet is needed for the
reasoning core and the natural voices.

## How the Master-only lock works

Every utterance is compared with your voiceprint (Resemblyzer). Below the match threshold it is dropped
before any speech recognition happens. Tune it in Settings (higher = stricter, lower = more forgiving).
It stops other people and the TV, but a high-quality recording of your voice could fool any voice-only
lock, so confirmation is still required before closing apps or killing processes.

## Tips

- Telugu accuracy improves a lot with Speech accuracy set to medium or large-v3 (GPU recommended).
- If the wake name is misheard, add spellings under `wake_aliases` in `~/.master_assistant/settings.json`,
  or turn the wake word off in Settings (the voice lock still protects you).
- Toggling Wi-Fi on Windows needs the app to run as administrator.
- Everything you store lives in `~/.master_assistant/`.
