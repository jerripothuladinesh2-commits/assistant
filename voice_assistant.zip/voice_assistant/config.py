"""Settings, memory and shared constants."""
import json
import threading
from pathlib import Path

APP_DIR = Path.home() / ".master_assistant"
APP_DIR.mkdir(exist_ok=True)
SETTINGS_FILE = APP_DIR / "settings.json"
MEMORY_FILE = APP_DIR / "memory.json"
NOTES_FILE = APP_DIR / "voice_notes.txt"
VOICEPRINT_FILE = APP_DIR / "voiceprint.npy"

# Languages the assistant understands and speaks.
LANGUAGES = {
    "en": {"name": "English", "native": "English", "voice": "en-GB-RyanNeural"},
    "te": {"name": "Telugu", "native": "తెలుగు", "voice": "te-IN-MohanNeural"},
    "hi": {"name": "Hindi", "native": "हिन्दी", "voice": "hi-IN-MadhurNeural"},
    "ta": {"name": "Tamil", "native": "தமிழ்", "voice": "ta-IN-ValluvarNeural"},
}

DEFAULTS = {
    "assistant_name": "Jarvis",
    "master_title": "Master",
    "api_key": "",
    "model": "claude-sonnet-5-5",
    "languages": ["en", "te", "hi", "ta"],
    "whisper_model": "small",        # small | medium | large-v3 (bigger = better Telugu, slower)
    "speaker_threshold": 0.72,       # lower = more forgiving, higher = stricter
    "require_wake_word": True,
    "wake_aliases": [],              # extra spellings Whisper may produce for the name
    "followup_seconds": 20,
    "input_device": None,
    "speak_replies": True,
}


class Settings:
    def __init__(self):
        self._lock = threading.Lock()
        self.data = dict(DEFAULTS)
        if SETTINGS_FILE.exists():
            try:
                self.data.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
            except Exception:
                pass

    def get(self, key):
        with self._lock:
            return self.data.get(key, DEFAULTS.get(key))

    def set(self, **kw):
        with self._lock:
            self.data.update(kw)
            SETTINGS_FILE.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")


class Memory:
    """Tiny persistent store for the Master's habits and preferences."""

    def __init__(self):
        self._lock = threading.Lock()
        self.data = {"preferences": {}}
        if MEMORY_FILE.exists():
            try:
                self.data.update(json.loads(MEMORY_FILE.read_text(encoding="utf-8")))
            except Exception:
                pass

    def remember(self, key, value):
        with self._lock:
            self.data["preferences"][key] = value
            MEMORY_FILE.write_text(json.dumps(self.data, indent=2, ensure_ascii=False), encoding="utf-8")

    def preferences(self):
        with self._lock:
            return dict(self.data["preferences"])


def detect_script_lang(text: str, default="en") -> str:
    """Pick the reply language from the script the text is written in."""
    counts = {"te": 0, "hi": 0, "ta": 0}
    for ch in text:
        o = ord(ch)
        if 0x0C00 <= o <= 0x0C7F:
            counts["te"] += 1
        elif 0x0900 <= o <= 0x097F:
            counts["hi"] += 1
        elif 0x0B80 <= o <= 0x0BFF:
            counts["ta"] += 1
    best = max(counts, key=counts.get)
    return best if counts[best] >= 2 else default
