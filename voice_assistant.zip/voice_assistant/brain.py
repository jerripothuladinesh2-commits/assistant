"""Claude-powered reasoning with tool use for laptop control."""
import datetime
import json
import os
import platform

LANG_NAMES = {"en": "English", "te": "Telugu", "hi": "Hindi", "ta": "Tamil"}


class Brain:
    def __init__(self, settings, memory, ctl):
        self.s, self.mem, self.ctl = settings, memory, ctl
        self.history = []
        self._client = None

    def _api(self):
        key = self.s.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            return None
        if self._client is None or getattr(self._client, "_key", None) != key:
            import anthropic
            self._client = anthropic.Anthropic(api_key=key)
            self._client._key = key
        return self._client

    def system_prompt(self):
        name, title = self.s.get("assistant_name"), self.s.get("master_title")
        langs = ", ".join(LANG_NAMES[l] for l in self.s.get("languages") if l in LANG_NAMES)
        prefs = json.dumps(self.mem.preferences(), ensure_ascii=False)
        return f"""You are {name}, a JARVIS/FRIDAY-style voice assistant living on the Master's {platform.system()} laptop. Address the user as "{title}". Be warm, respectful, articulate and lightly witty.

Languages: you understand {langs}. Always answer in the language the Master spoke, written in that language's own script (Telugu in Telugu script, Hindi in Devanagari, Tamil in Tamil script). If they mix languages, follow the dominant one.

Your replies are read aloud by a text-to-speech voice. Write plain spoken sentences: no markdown, no bullet lists, no emoji, no code. Keep it to one to three short sentences unless asked to elaborate. Spell out units naturally ("fifty percent").

When the Master gives a command, call the right tool, then confirm briefly in one line (for example "Opening Spotify and setting the volume to fifty percent, {title}.").

Critical situations (lag during a presentation, overheating, low battery, crash risk, security alerts): drop the wit. Be calm, short and decisive. Step one, reassure. Step two, diagnose with get_system_status. Step three, take the safest fix. Safe actions such as lowering brightness or switching to saver mode you may do immediately. Closing apps or killing processes needs the Master's yes first, and never touch protected system processes.

Only the Master's voice reaches you, but never expose private data or run destructive actions without confirmation.
Known preferences: {prefs}
Current time: {datetime.datetime.now():%A %d %B %Y, %H:%M}."""

    def note_assistant(self, text):
        """Record something the assistant said on its own (alerts, timers) so follow-ups make sense."""
        if not self.history:
            self.history.append({"role": "user", "content": "(session started)"})
        self.history.append({"role": "assistant", "content": text})

    def _trim(self):
        if len(self.history) > 24:
            self.history = self.history[-24:]
        while self.history and not (self.history[0]["role"] == "user" and isinstance(self.history[0]["content"], str)):
            self.history.pop(0)

    def ask(self, text):
        client = self._api()
        if client is None:
            return "I need an Anthropic API key to think, Master. Please add it in Settings."
        start = len(self.history)
        self.history.append({"role": "user", "content": text})
        self._trim()
        tools = self.ctl.tools()
        try:
            for _ in range(6):
                resp = client.messages.create(
                    model=self.s.get("model"), max_tokens=500, system=self.system_prompt(),
                    tools=tools, messages=self.history)
                self.history.append({"role": "assistant", "content": resp.content})
                calls = [b for b in resp.content if b.type == "tool_use"]
                if not calls:
                    return " ".join(b.text for b in resp.content if b.type == "text").strip() or "Done."
                results = [{"type": "tool_result", "tool_use_id": c.id,
                            "content": self.ctl.run(c.name, c.input)} for c in calls]
                self.history.append({"role": "user", "content": results})
            return "That took more steps than expected, Master. Please check the result."
        except Exception as e:
            del self.history[min(start, len(self.history)):]
            return f"I could not reach my reasoning core. {type(e).__name__}: {str(e)[:120]}"
