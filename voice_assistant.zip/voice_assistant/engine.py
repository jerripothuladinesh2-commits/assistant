"""Pipeline: mic -> Master check -> speech-to-text -> wake word -> Claude -> voice."""
import datetime
import difflib
import queue
import re
import threading
import time

from PySide6.QtCore import QObject, Signal

from brain import Brain
from config import Memory, Settings, detect_script_lang
from system_control import SystemControl
from voice import Listener, SpeakerVerifier, Transcriber, Voice

ENROLL_PHRASES = [
    "Hello, this is my voice, and only I command this laptop.",
    "The quick brown fox jumps over the lazy dog near the river.",
    "Open my files, check the battery, and play some music.",
    "Today is a good day to finish everything on my list.",
    "Set a timer, lower the brightness, and keep me informed.",
    "Please recognise my voice whenever I call your name.",
]


class Bus(QObject):
    state = Signal(str)                 # loading | idle | listening | thinking | speaking | alert | muted
    level = Signal(float)
    status = Signal(str)
    transcript = Signal(str, str, str)  # role, text, lang
    verified = Signal(bool, float)
    lang = Signal(str)
    settings_changed = Signal()
    enrolled = Signal(bool)


class Engine:
    def __init__(self, bus: Bus):
        self.bus = bus
        self.s, self.mem = Settings(), Memory()
        self.verifier = SpeakerVerifier()
        self.stt = Transcriber(self.s)
        self.tts = None
        self.ctl = SystemControl(self.s, self.mem, notify=self.proactive,
                                 on_settings=lambda: self.bus.settings_changed.emit())
        self.brain = Brain(self.s, self.mem, self.ctl)
        self.q = queue.Queue()
        self.listener = None
        self.last_active = 0.0
        self.handle_lock = threading.Lock()
        self.speak_lock = threading.Lock()
        self.ready = False

    # ---------- lifecycle ----------
    def start(self):
        threading.Thread(target=self._boot, daemon=True).start()

    def _boot(self):
        b = self.bus
        b.state.emit("loading")
        b.status.emit("Loading speech models. The first launch downloads them and can take a few minutes.")
        try:
            self.tts = Voice(self.s)
        except Exception as e:
            b.status.emit(f"Audio output unavailable: {e}")
        try:
            self.stt.load()
        except Exception as e:
            b.status.emit(f"Speech model failed to load: {e}")
            return
        self.listener = Listener(self._on_utterance, self._on_level,
                                 lambda: self.bus.state.emit("listening"), self.s.get("input_device"))
        self.listener.start()
        threading.Thread(target=self._worker, daemon=True).start()
        self.ready = True
        b.enrolled.emit(self.verifier.enrolled)
        b.state.emit("idle")
        if self.verifier.enrolled:
            self.greet()
        else:
            b.status.emit("Say hello once your voice is enrolled. Tap Enroll my voice to begin.")

    def greet(self):
        h = datetime.datetime.now().hour
        part = "morning" if h < 12 else "afternoon" if h < 18 else "evening"
        t = self.s.get("master_title")
        self.bus.status.emit(self._ready_msg())
        self.proactive(f"Good {part}, {t}. {self.s.get('assistant_name')} is online and ready.")

    def _ready_msg(self):
        name = self.s.get("assistant_name")
        if self.s.get("require_wake_word"):
            return f"Say “{name}” to wake me, or tap the orb."
        return "Listening. Speak any time."

    def _on_level(self, rms):
        self.bus.level.emit(min(1.0, rms * 9))

    # ---------- incoming audio ----------
    def _on_utterance(self, audio, bypass):
        self.q.put((audio, bypass))

    def _worker(self):
        while True:
            audio, bypass = self.q.get()
            try:
                self._process(audio, bypass)
            except Exception as e:
                self.bus.status.emit(f"Error: {e}")
                self.bus.state.emit("idle")

    def _process(self, audio, bypass):
        if not self.verifier.enrolled:
            self.bus.status.emit("Your voice is not enrolled yet. Tap Enroll my voice.")
            self.bus.state.emit("idle")
            return
        score = self.verifier.score(audio)
        ok = score >= self.s.get("speaker_threshold")
        self.bus.verified.emit(ok, score)
        if not ok:
            self.bus.state.emit("idle")
            return
        self.bus.state.emit("thinking")
        name = self.s.get("assistant_name")
        text, lang = self.stt.transcribe(audio, prompt=f"{name}.")
        self.bus.lang.emit(lang)
        if not text:
            self.bus.state.emit("idle")
            return
        awake = bypass or (time.time() - self.last_active) < self.s.get("followup_seconds")
        if self.s.get("require_wake_word") and not awake:
            found, text = self._strip_wake(text)
            if not found:
                self.bus.state.emit("idle")
                return
            if not text.strip():
                self.say(f"Yes, {self.s.get('master_title')}?", "en")
                self.last_active = time.time()
                return
        self.handle_text(text, lang)

    def _strip_wake(self, text):
        name = self.s.get("assistant_name").lower()
        names = {name, *[a.lower() for a in self.s.get("wake_aliases")]}
        words = re.findall(r"\S+", text)
        for i, w in enumerate(words):
            clean = re.sub(r"[^\w]", "", w.lower())
            if any(clean == n or difflib.SequenceMatcher(None, clean, n).ratio() >= 0.75 for n in names):
                return True, " ".join(words[:i] + words[i + 1:]).strip(" ,.!?")
        return False, text

    # ---------- handling ----------
    def submit_text(self, text):
        threading.Thread(target=self.handle_text, args=(text, "en"), daemon=True).start()

    def handle_text(self, text, lang="en"):
        with self.handle_lock:
            self.last_active = time.time()
            self.bus.transcript.emit("you", text, lang)
            self.bus.state.emit("thinking")
            reply = self.brain.ask(text)
            rl = detect_script_lang(reply, lang if lang != "en" else "en")
            self.bus.transcript.emit("assistant", reply, rl)
            self.say(reply, rl)
            self.last_active = time.time()

    def proactive(self, text):
        """Assistant speaks on its own (alerts, timers, greeting)."""
        self.brain.note_assistant(text)
        lang = detect_script_lang(text)
        self.bus.transcript.emit("assistant", text, lang)
        threading.Thread(target=self.say, args=(text, lang), daemon=True).start()
        self.last_active = time.time()

    def say(self, text, lang="en"):
        with self.speak_lock:
            if self.listener:
                self.listener.paused = True
            self.bus.state.emit("speaking")
            try:
                if self.tts:
                    self.tts.speak(text, lang)
            finally:
                time.sleep(0.3)
                if self.listener:
                    self.listener.paused = False
                self.bus.state.emit("muted" if self.listener and self.listener.muted else "idle")

    def stop_speaking(self):
        if self.tts:
            self.tts.stop()

    def listen_now(self):
        """Tap-to-talk: next utterance skips the wake word."""
        if self.listener:
            self.listener.muted = False
            self.listener.armed = True
            self.bus.state.emit("listening")
            self.bus.status.emit("I'm listening.")

    def toggle_mute(self):
        if not self.listener:
            return False
        self.listener.muted = not self.listener.muted
        self.bus.state.emit("muted" if self.listener.muted else "idle")
        self.bus.status.emit("Microphone is off." if self.listener.muted else self._ready_msg())
        return self.listener.muted

    # ---------- enrolment ----------
    def enroll(self):
        threading.Thread(target=self._enroll, daemon=True).start()

    def _enroll(self):
        if not self.ready:
            self.bus.status.emit("Still loading models. Try again in a moment.")
            return
        b, clips = self.bus, []
        self.listener.muted = False
        self.listener.capture_q = queue.Queue()
        try:
            for i, phrase in enumerate(ENROLL_PHRASES, 1):
                while True:
                    b.state.emit("idle")
                    b.status.emit(f"Voice setup {i} of {len(ENROLL_PHRASES)}: say “{phrase}”")
                    try:
                        clip = self.listener.capture_q.get(timeout=25)
                    except queue.Empty:
                        raise RuntimeError("No speech heard. Check your microphone and try again.")
                    if len(clip) >= 16000 * 1.5:
                        clips.append(clip)
                        break
                    b.status.emit("That was a bit short. Please say the full sentence.")
            b.state.emit("thinking")
            b.status.emit("Learning your voice…")
            self.verifier.enroll(clips)
            b.enrolled.emit(True)
            b.state.emit("idle")
            self.greet()
        except Exception as e:
            b.status.emit(str(e))
            b.state.emit("idle")
        finally:
            self.listener.capture_q = None

    def reset_voiceprint(self):
        self.verifier.reset()
        self.bus.enrolled.emit(False)
        self.bus.status.emit("Voiceprint removed. Enroll again to unlock voice control.")
