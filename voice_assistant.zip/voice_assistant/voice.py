"""Microphone listener, speaker verification (Master-only), speech-to-text, text-to-speech."""
import asyncio
import collections
import os
import queue
import tempfile
import threading
import time

import numpy as np
import sounddevice as sd

from config import LANGUAGES, VOICEPRINT_FILE

SR = 16000


class Listener(threading.Thread):
    """Always-on mic with adaptive voice-activity detection. Emits whole utterances."""

    def __init__(self, on_utterance, on_level, on_speech_start, device=None):
        super().__init__(daemon=True)
        self.on_utterance = on_utterance
        self.on_level = on_level
        self.on_speech_start = on_speech_start
        self.device = device
        self.paused = False          # set while the assistant is speaking
        self.muted = False           # set by the mic button
        self.armed = False           # next utterance skips the wake word
        self.capture_q = None        # enrolment mode: utterances go here instead
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        block = int(SR * 0.03)
        pre = collections.deque(maxlen=10)
        frames, speaking, silence, noise = [], False, 0, 0.01
        try:
            stream = sd.InputStream(samplerate=SR, channels=1, dtype="float32",
                                    blocksize=block, device=self.device)
        except Exception as e:
            self.on_level(-1)
            print("Microphone error:", e)
            return
        with stream:
            while not self._stop:
                data, _ = stream.read(block)
                x = data[:, 0].copy()
                rms = float(np.sqrt(np.mean(x ** 2)))
                self.on_level(rms)
                if self.paused or self.muted:
                    frames, speaking, silence = [], False, 0
                    pre.clear()
                    continue
                if not speaking:
                    noise = 0.97 * noise + 0.03 * rms
                thr = max(0.012, noise * 3.2)
                if rms > thr:
                    if not speaking:
                        speaking = True
                        frames = list(pre)
                        self.on_speech_start()
                    silence = 0
                    frames.append(x)
                elif speaking:
                    frames.append(x)
                    silence += 1
                    if silence > 28 or len(frames) > 500:     # ~0.85 s quiet or 15 s cap
                        audio = np.concatenate(frames)
                        frames, speaking, silence = [], False, 0
                        if len(audio) > SR * 0.5:
                            if self.capture_q is not None:
                                self.capture_q.put(audio)
                            else:
                                bypass, self.armed = self.armed, False
                                self.on_utterance(audio, bypass)
                else:
                    pre.append(x)


class SpeakerVerifier:
    """Voiceprint check so only the Master's voice is accepted."""

    def __init__(self):
        self._enc = None
        self.ref = None
        if VOICEPRINT_FILE.exists():
            try:
                self.ref = np.load(VOICEPRINT_FILE)
            except Exception:
                self.ref = None

    @property
    def enrolled(self):
        return self.ref is not None

    def _encoder(self):
        if self._enc is None:
            from resemblyzer import VoiceEncoder
            self._enc = VoiceEncoder(verbose=False)
        return self._enc

    def embed(self, audio):
        from resemblyzer import preprocess_wav
        wav = preprocess_wav(audio.astype(np.float32), source_sr=SR)
        if len(wav) < SR * 0.4:
            return None
        return self._encoder().embed_utterance(wav)

    def enroll(self, clips):
        embs = [e for e in (self.embed(c) for c in clips) if e is not None]
        if len(embs) < 3:
            raise RuntimeError("Not enough clear speech. Please try again in a quieter room.")
        ref = np.mean(embs, axis=0)
        ref /= np.linalg.norm(ref)
        np.save(VOICEPRINT_FILE, ref)
        self.ref = ref

    def reset(self):
        self.ref = None
        if VOICEPRINT_FILE.exists():
            VOICEPRINT_FILE.unlink()

    def score(self, audio):
        if self.ref is None:
            return 0.0
        e = self.embed(audio)
        return 0.0 if e is None else float(np.dot(e, self.ref))


class Transcriber:
    """faster-whisper with language detection restricted to the languages you enabled."""

    def __init__(self, settings):
        self.s = settings
        self.model = None

    def load(self):
        from faster_whisper import WhisperModel
        self.model = WhisperModel(self.s.get("whisper_model"), device="auto", compute_type="int8")

    def transcribe(self, audio, prompt=""):
        allowed = self.s.get("languages") or ["en"]
        audio = audio.astype(np.float32)
        lang = allowed[0]
        try:
            probs = dict(self.model.detect_language(audio)[2])
            lang = max(allowed, key=lambda l: probs.get(l, 0.0))
        except Exception:
            pass
        segs, _ = self.model.transcribe(
            audio, language=lang, beam_size=5, vad_filter=True,
            initial_prompt=prompt or None, condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segs).strip(), lang


class Voice:
    """Neural TTS (edge-tts) with an offline fallback."""

    def __init__(self, settings):
        self.s = settings
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        import pygame
        pygame.mixer.init()
        self.pg = pygame
        self._stop = False

    def stop(self):
        self._stop = True
        try:
            self.pg.mixer.music.stop()
        except Exception:
            pass

    def speak(self, text, lang="en"):
        if not self.s.get("speak_replies") or not text.strip():
            return
        self._stop = False
        path = None
        try:
            import edge_tts
            voice = LANGUAGES.get(lang, LANGUAGES["en"])["voice"]
            fd, path = tempfile.mkstemp(suffix=".mp3")
            os.close(fd)
            asyncio.run(edge_tts.Communicate(text, voice, rate="+6%").save(path))
            self.pg.mixer.music.load(path)
            self.pg.mixer.music.play()
            while self.pg.mixer.music.get_busy() and not self._stop:
                time.sleep(0.05)
            self.pg.mixer.music.unload()
        except Exception:
            self._offline(text)
        finally:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass

    def _offline(self, text):
        try:
            import pyttsx3
            eng = pyttsx3.init()
            eng.say(text)
            eng.runAndWait()
        except Exception:
            pass
